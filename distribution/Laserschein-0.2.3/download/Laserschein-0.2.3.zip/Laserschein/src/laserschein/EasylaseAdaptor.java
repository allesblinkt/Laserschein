package laserschein;


public class EasylaseAdaptor extends AbstractLaserOutput {

	@Override
	public void initialize() {
		// TODO fill me
		
	}

	@Override
	public void draw(LaserFrame theFrame) {
		// TODO fill me
		
	}

	@Override
	public void destroy() {
		// TODO fill me
		
	}

}
