package laserschein;

public enum NativeState {
	UNINITIALIZED, 
	UNSUPPORTED_PLATFORM, 
	NOT_FOUND, 
	READY 
}
