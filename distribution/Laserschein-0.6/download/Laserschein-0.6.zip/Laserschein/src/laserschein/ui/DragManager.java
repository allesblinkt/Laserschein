/**
 *  
 *  Laserschein. interactive ILDA output from processing and java
 *
 *  2011 by Benjamin Maus
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA
 *
 * @author Benjamin Maus (http://www.allesblinkt.com)
 *
 */
package laserschein.ui;

import java.util.ArrayList;


public class DragManager {
	  private final ArrayList<Draggable> _myElements; 
	  Draggable active = null;

	  float diffX;
	  float diffY;

	  
	  public DragManager() {
	    _myElements = new ArrayList<Draggable>();
	  } 

	  
	  public void add(Draggable theElement) {
	    _myElements.add(theElement);
	  }

	  
	  public void draw() {
	    if (active != null) {
	    } 
	    else {
	    }
	  }


	  public void pressed(float theX, float theY) {
	    for (Draggable element: _myElements) {
	      if (element.mouseOver(theX, theY) ) {
	        active = element;
	      }
	    } 

	    if (active != null) {
	      diffX = active.x() - theX;
	      diffY = active.y() - theY;
	    }
	  }


	  public void dragged(float theX, float theY) {
	    if (active != null) {
	      active.x(theX + diffX); 
	      active.y(theY + diffY);
	    }
	  }


	  public void released() {
	    active = null;
	  }
	}
